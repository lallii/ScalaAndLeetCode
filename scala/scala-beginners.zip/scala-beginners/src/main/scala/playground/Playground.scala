package playground

object Playground {
  def main(args: Array[String]): Unit = {
     println("learn scala")
  }
}
