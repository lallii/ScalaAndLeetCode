package oop

object OOBasics extends App{
    val person=new Person
    println(person)
}
class Person